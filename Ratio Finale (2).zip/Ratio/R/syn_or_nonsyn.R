# File: R/syn_or_nonsyn.R

#' Determiner si une subtitution est synonyme ou non synonyme
#'
#' Cette fonction determine si une subtitution est synonyme ou non synonyme en comparant les codons d'une sequence donnee aux codons de la sequence de reference.
#'
#' @param codon_ref Codons de la sequence de reference.
#' @param codon_mut Codons de la sequence focale.
#' @param gen_code Table du code genetique.
#' @return Une liste indiquant si la subtitution est synonyme ou non synonyme.
#' @export

syn_or_nonsyn <-
  function(codon_ref, codon_mut, gen_code) {
    in_codons <- c(codon_ref, codon_mut)
    result <- list(ref = codon_ref, mut = 'xxx', s = 0, n = 0)

    # Verification des arguments
    if (missing(codon_ref) || !is.character(codon_ref) || nchar(codon_ref) != 3) {
      stop("Argument 'codon_ref' manquant ou non valide. Il doit etre une chaine de caracteres de trois nucleotides representant le premier codon.")
    }
    if (missing(codon_mut) || !is.character(codon_mut) || nchar(codon_mut) != 3) {
      stop("Argument 'codon_mut' manquant ou non valide. Il doit etre une chaine de caracteres de trois nucleotides representant le deuxieme codon.")
    }
    if (missing(gen_code) || !is.character(gen_code)) {
      stop("Argument 'gen_code' manquant ou non valide. Il doit etre une chaine de caracteres representant le code genetique a utiliser.")
    }

    codon_1_invalid <- grepl(pattern = '[^ATGC]', x = in_codons[1])
    codon_2_invalid <- grepl(pattern = '[^ATGC]', x = in_codons[2])
    if (codon_1_invalid | codon_2_invalid) {
      return(result)
    }

    if (length(in_codons) != 2) {
      stop('ARGHHH it is not only two codons, we are all going to die !')
    }

    if (codon_ref == codon_mut) {
      stop('Biology 101 much ?')
    }
    out_aa <-
      gen_code$AA[sapply(X = in_codons, FUN = function(x) grep(pattern = x, x = gen_code$codon))]


    if (out_aa[1] == out_aa[2]) {
      result <- list(ref = codon_ref,
                     mut = codon_mut,
                     aa_ref = out_aa[1],
                     aa_mut = out_aa[2],
                     s = 1, n = 0)
    } else if (out_aa[1] != out_aa[2] ) {
      result <- list(ref = codon_ref,
                     mut = codon_mut,
                     aa_ref = out_aa[1],
                     aa_mut = out_aa[2],
                     s = 0, n = 1)
    }
    return(result)
  }

