# File: R/final_KaKs.R

#' Calculer les ratios finaux Ka/Ks
#'
#' Cette fonction calcule les ratios finaux Ka/Ks pour chaque paire de séquence en tenant compte des cas particuliers où il n'y a pas de mutations synonymes détectés.
#'
#' @param df Data frame contenant les données de séquences et les valeurs Ka/Ks.
#' @return Un data frame avec les ratios Ka/Ks finaux.
#' @export

final_KaKs <- function(df) {
  df$id <-
    paste0(df$seq_1, df$seq_2)
  uni_id <-
    unique(df$id)
  n_uni <- length(uni_id)
  out_df <- data.frame(seq_1 = rep(NA, n_uni),
                       seq_2 = rep(NA, n_uni),
                       KaKs = rep(NA, n_uni))
  for (i in 1:n_uni) {
    curr_df <-
      df[df$id == uni_id[i], ]

    out_df$seq_1[i] <- curr_df$seq_1[1]
    out_df$seq_2[i] <- curr_df$seq_2[1]

    # remove 0/0 --> NaN
    if (sum(curr_df$Ka) == 0 & sum(curr_df$Ks) == 0) {
      out_df$KaKs[i] <- NA}

    # add one synonymous mutation when ka > 0 and ks = 1
    else if (sum(curr_df$Ka) > 0 & sum(curr_df$Ks) == 0) {
      #ks_corr <- (1/62)/curr_df$S[curr_df$S>0]/curr_df$count[curr_df$S>0]
      #out_df$KaKs[i] <-  sum(curr_df$Ka) / mean(ks_corr)
      z <- stats::sd(1/curr_df$S[curr_df$S>0]/curr_df$count[curr_df$S>0])
      #ks_corr <- 1/curr_df$S[curr_df$S>0]/curr_df$count[curr_df$S>0]
      #ka_corr <- 1/curr_df$N[curr_df$N>0]/curr_df$count[curr_df$N>0]
      out_df$KaKs[i] <-  (sum(curr_df$Ka) + 1*z) / (1*z)

    } else {out_df$KaKs[i] <-  sum(curr_df$Ka) / sum(curr_df$Ks)}


  }
  return(out_df)

}
