replace_non_ascii <- function(file) {
  content <- readLines(file, encoding = "UTF-8")
  content <- iconv(content, from = "UTF-8", to = "ASCII//TRANSLIT")
  writeLines(content, file, useBytes = TRUE)
}

replace_non_ascii("R/kaks.R")
replace_non_ascii("R/syn_or_nonsyn.R")
