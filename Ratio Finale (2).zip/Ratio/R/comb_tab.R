# File: R/comb_tab.R

#' Créer une table de combinaisons de séquences
#'
#' Cette fonction crée une table de combinaisons de séquences pour toutes les paires de séquences dans un fichier FASTA.
#'
#' Crée toutes les combinaisons possibles de paires de séquences avec leir indices à partir d'un fichier d'alignement de séquences.
#'
#' @param temp_fasta Chemin vers le fichier FASTA temporaire.
#' @return Une data.frame contenant les combinaisons deux à deux des séquences et leurs indices.
#' @export

comb_tab <- function(temp_fasta) {
  n_lines <- length(readLines(temp_fasta))
  seq.names <- integer(0)
  for (i in seq(0, (n_lines - 1), 2)) {
    seq.names <- c(seq.names, n.readLines(temp_fasta, n = 1, skip = i))
  }
  seq.names <- gsub(">", "", seq.names)

  index.combn <- as.matrix(t(expand.grid(seq(1, n_lines, 2), seq(1, n_lines, 2))))
  seq.combn <- as.matrix(t(expand.grid(seq.names, seq.names)))

  dup <- index.combn[1,] == index.combn[2,]
  index.combn <- index.combn[ ,!dup]
  seq.combn <- seq.combn[ ,!dup]

  result <- data.frame(cbind(t(seq.combn), t(index.combn)))

  colnames(result) <- c("seq_1", "seq_2", "index_1", "index_2")
  result$index_1 <- as.integer(result$index_1)
  result$index_2 <- as.integer(result$index_2)
  return(result)
}
