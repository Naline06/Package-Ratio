# File: R/find_mismatches.R

#' Trouver les positions de discordance entre deux séquences
#'
#' Cette fonction trouve les positions des discordances entre deux séquences.
#'
#' @param seq_1 Première séquence.
#' @param seq_2 Deuxième séquence.
#' @return Un vecteur des positions des discordances.
#' @export

find_mismatches <- function(seq_1, seq_2) {
  if (length(seq_1) != length(seq_2)) {
    stop('OHHHH NOOOOOO, ONE OF THEM IS TOO LONG AND THE OTHER TOO SHORT, WHY G*D WHY HAVE YOU FORSAKEN US!')
  }
  mis <- which(seq_1 != seq_2)
  return(mis)
}
