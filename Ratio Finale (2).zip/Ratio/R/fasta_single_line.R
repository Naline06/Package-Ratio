# File: R/fasta_single_line.R

#' Convertir un fichier FASTA multi-lignes en une seule ligne par sequence.
#'
#' Cette fonction lit un fichier FASTA contenant des sequences sur plusieurs lignes et ecrit un nouveau fichier FASTA avec chaque sequence sur une seule ligne.
#'
#' @param input_file Chemin du fichier FASTA d'entree.
#' @param output_file Chemin du fichier FASTA de sortie.
#' @return Un message indiquant que le fichier a ete converti avec succes.
#' @export
#' @import seqinr

fasta_single_line <- function(input_file, output_file) {
  sequences <- read.fasta(input_file)

  seq_list <- lapply(1:length(sequences), function(i) {
    paste(sequences[[i]], collapse = "")
  })

  write.fasta(names = names(sequences), sequences = seq_list, file.out = output_file)

  return(paste("Fichier converti avec succes", output_file))
}
