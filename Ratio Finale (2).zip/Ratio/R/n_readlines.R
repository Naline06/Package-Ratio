# File: R/n_readLines.R

#' Lire un nombre spécifié de lignes à partir d'un fichier
#'
#' Cette fonction lit au moins 'n' lignes d'un fichier, en ignorant les lignes de commentaire et en sautant les lignes spécifiées.
#'
#' Lit un nombre spécifié de lignes à partir d'un fichier,en sautant les lignes de commentaires et éventuellement un nombres données de ligne initiales.
#'
#' @param fn Chemin du fichier FASTA à lire.
#' @param n Nombre de lignes à lire.
#' @param comment Caractère de commentaire (par défaut '#').
#' @param skip Nombre de lignes à sauter au début du fichier (par défaut 0).
#' @param header Indique si la première ligne doit être traitée comme un en-tête (par défaut FALSE).
#' @return Un vecteur de chaînes de caractères contenant les lignes lues.
#' @export
#' @examples
#' n.readLines("data.txt", 10)

n.readLines <- function(fn, n, comment="#", skip=0, header=FALSE) {
  if(!file.exists(fn)) { warning("file doesn't exist"); return(NULL) }
  if(!is.character(comment)) { warning("illegal comment char, reverting to #"); comment <- "#" }
  rl <- 0; cc <- 0 + {if(is.numeric(skip)) skip else 0 }
  while(rl < n) {
    test.bit <- readLines(fn, n + cc)
    if(skip > 0 & length(test.bit > 1)) { test.bit <- test.bit[-(1:(min((length(test.bit) - 1), skip)))] }
    cmnt <- which(substr(test.bit, 1, 1) == comment)
    rl <- n + cc - length(cmnt)
    cc <- cc + length(cmnt)
  }
  if(length(cmnt) > 0) { test.bit <- test.bit[-cmnt] }
  if(length(test.bit) > 1 & header) { test.bit <- test.bit[-1] }
  return(test.bit)
}
