# File: R/kaks.R

#' Calculer les ratios Ka/Ks pour des sequences codantes alignees
#'
#' Cette fonction calcule les ratios de substitutions non-synonymes (Ka) et synonymes (Ks) pour des sequences codantes alignees.
#'
#' @param full_orf_aln Chemin vers le fichier FASTA contenant les sequences codantes alignees.
#' @param genetic_code_path Chemin vers le fichier du code genetique. Par defaut './data/genetic_code.txt'.
#' @param sn_table_path Chemin vers le fichier de table des codons synonymes et non synonymes. Par defaut './data/SN_codonTable.txt'.
#' @param n_core Nombre de coeurs a utiliser pour le calcul en parallele. Par defaut 1.
#' @return Une liste contenant les donnees de sortie et les ratios Ka/Ks.
#'  \describe{
#'   \item{ka}{Le taux de substitutions non synonymes attendues (substitutions qui changent l'acide amine).}
#'   \item{ks}{Le taux de substitutions synonymes attendues (substitutions qui ne changent pas l'acide amine).}
#'   \item{ka_ks_ratio}{Le rapport entre les taux de substitutions non synonymes et synonymes.}
#' }
#' @import foreach
#' @import doParallel
#' @import seqinr
#' @examples
# Chemin vers les fichiers de donnees dans le package
# Pour que le package fonctionne correctement il est necessaire d'inclure les fichiers de donnees
# Pour acceder a ces fichiers il faut excuter les ci-dessous dans votre console de travail apres l'installation du package.

#' pathExample <- paste(system.file("extdata", package = "Ratio"),"data.fasta", sep= "/")
#' La commande system.file("extdata", package = "Ratio") localise le repertoire 'exdata' a l'interieur du package Ratio installe sur le systeme. Ensuite, on utilise la fonction 'paste' pour ajouter le nom du fichier 'data.fasta' a ce chemin.
#' Le fichier data.fasta contient des sequences nucleotiques au format FASTA.
#'
#' sn_table_path <- paste(system.file("extdata", package = "Ratio"),"SN_Table.txt", sep= "/")
#' Comme precedemment, la commande trouve le repertoire 'exdata' dans le package 'Ratio'
#' Le fichier 'SN_Table.txt' contient une table de codons avec des informations sur les mutations synonymes et non-synonymes.
#'
#' genetic_code_path <- paste(system.file("extdata", package = "Ratio"),"genetic_code.txt", sep= "/")
#' Le fichier genetic_code.txt contient les informations du code genetique, qui associent les codons aux acides amines correspondants.
#' @export
kaks <- function(full_orf_aln, genetic_code_path, sn_table_path, n_core=1)

  # Verification des arguments
  {
  if (!file.exists(genetic_code_path)) {
    stop(paste("Le fichier specifie dans 'genetic_code_path' n'existe pas :", genetic_code_path))
  }
  if (!file.exists(sn_table_path)) {
    stop(paste("Le fichier specifie dans 'sn_table_path' n'existe pas :", sn_table_path))
  }
  if (!is.numeric(n_core) || n_core <= 0) {
    stop("Argument 'n_core' non valide. Il doit etre un entier positif.")
  }

  #Ecrire les sequences sur une seule ligne dans un fichier temporaire

  #temp_fasta <- tempfile(fileext = "temp.fasta")
  temp_fasta <- "temp.fasta"
  fasta_single_line(full_orf_aln, temp_fasta)

  # Lire les sequences FASTA
  sequences <- read.fasta(temp_fasta)

  # getting sequence names and indexes
  all_comb <- comb_tab(temp_fasta)

  # Creating the output list
  # output_list <-
  # vector(mode = 'list', length = nrow(all_comb))
  # my_clust <- makeCluster(spec = n_core, type = 'FORK')
  # registerDoParallel(cl = my_clust, cores = n_core)
  registerDoParallel(cores = n_core)
  # for (i in 1:nrow(all_comb)) {
  output_list <-
    foreach(i = 1:nrow(all_comb)) %dopar% {
      source("kaks.R")
      seq_names <-
        c(all_comb$seq_1[i], all_comb$seq_2[i])
      seq_index <-
        c(all_comb$index_1[i], all_comb$index_2[i])
      # Checking current names and indexes
      if (seq_names[1] == seq_names[2]) {
        stop('Identical sequences names !')
      }
      if (seq_index[1] == seq_index[2]) {
        stop('Identical sequences names !')
      }

      if (length(seq_names) < 2 || length(seq_index) < 2) {
        stop('Not enough sequence indexes or name')
      }

      if (length(seq_names) > 2 || length(seq_index) > 2) {
        message('Too many sequence indexes or name !')
        message('Only the first two will be used')
      }

      # creating empty output table
      mut_table <- genetic_code
      mut_table$seq_1 <- seq_names[1] # as.factor(seq_names[1])
      mut_table$seq_2 <- seq_names[2] # as.factor(seq_names[2])
      mut_table$s <- 0
      mut_table$n <- 0

      cat('Step', i, '/', nrow(all_comb),'\n')
      cat('Computing sequence', seq_names[1],' vs ', seq_names[2], '\n')

      # reading first sequence as a reference

      ref <-
        read_codons(file = temp_fasta, n = 1, to_skip = seq_index[1])
      # counting codons in REF
      ref_count <- codon_counter(ref, sn_table= SN_table)
      # reading the second sequences

      curr_seq <-
        read_codons(file = temp_fasta, n = 1, to_skip = seq_index[2])
      # finding mismatches positions
      curr_mismatches <-
        find_mismatches(seq_1 = ref, seq_2 = curr_seq)

      if (length(curr_mismatches) == 0) {
        cat('The sequences', seq_names[1],' and ', seq_names[2], ' are identical !\n')
        return(NA)
      }

      for (j in 1:length(curr_mismatches)) {
        # print(ref[curr_mismatches[i]])
        # print(curr_seq[curr_mismatches[i]])
        curr_mut <- syn_or_nonsyn(codon_ref = ref[curr_mismatches[j]],
                                  codon_mut = curr_seq[curr_mismatches[j]],
                                  gen_code = genetic_code)
        mut_table$s[mut_table$codon == curr_mut$ref[1]] <-
          mut_table$s[mut_table$codon == curr_mut$ref[1]] + curr_mut$s[1]
        mut_table$n[mut_table$codon == curr_mut$ref[1]] <-
          mut_table$n[mut_table$codon == curr_mut$ref[1]] + curr_mut$n[1]
      }
      mut_table <- merge(ref_count, mut_table, by = 'codon')
      curr_output <- compute_kaKs(mutation_table = mut_table)
      order_wanted <- c('seq_1', 'seq_2','codon', 'AA','count', 'S', 'N', 's', 'n', 'Ks', 'Ka')
      curr_output <- curr_output[ , order_wanted]
      # cat('Ka/Ks is', round(curr_output[[2]], 3),'\n')
      cat('\n...\n\n')
      return(curr_output) # to get the result into output_list
    }

  output_df <- do.call(what = rbind, output_list)
  output_df <- output_df[stats::complete.cases(output_df), ]
  kaks_df <- final_KaKs(df = output_df)

  file.remove(temp_fasta)
  return(list(output_df, kaks_df))

}

