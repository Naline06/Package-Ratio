# File: R/read_codons.R

#' Lire des codons à partir d'un fichier
#'
#' Cette fonction lit des codons à partir d'un fichier FASTA, en sautant un nombre spécifié de lignes.
#'
#' Elle lit les codons d'une séquence dans un fichier d'alignement les formates et les retourne sous forme de vecteur.
#'
#' @param file Chemin du fichier FASTA à lire.
#' @param n Nombre de lignes à lire (par défaut 1).
#' @param to_skip Nombre de lignes à sauter avant de lire .
#' @return Un vecteur de codons.
#' @export

read_codons <- function(file, n = 1, to_skip) {
  codons <- n.readLines(fn = file, n = n, skip = to_skip, header = FALSE)
  codons <- toupper(codons)
  codons <- gsub(pattern = '(.{3})', replacement = '\\1;', x = codons)
  codons <- strsplit(x = codons, split = ';', fixed = TRUE)[[1]]
  return(codons)
}
