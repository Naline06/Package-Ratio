# File: R/compute_kaKs.R

#' Calculer les valeurs Ka et Ks
#'
#' Cette fonction calcule le nombre de substitutions synonymes (Ks) et non synonymes (Ka) pour une table contenant les codons mutés.
#'
#' @param mutation_table Table contenant les codons mutés
#' @return Une table des codons mutés avec les valeurs Ka et Ks calculées.
#' @export

compute_kaKs <- function(mutation_table) {
  # ATG/M and TTG/W are unique, hence the divide by 0
  mutation_table$Ks <- mutation_table$s / (mutation_table$S * mutation_table$count)
  mutation_table$Ks[is.na(mutation_table$Ks)] <- 0
  mutation_table$Ka <- mutation_table$n / (mutation_table$N * mutation_table$count)
  if (sum(mutation_table$Ks) == 0) {
    cat('No synonymous mutation detected !\n')
  }
  if (sum(mutation_table$Ka) == 0) {
    cat('No non-synonymous mutation detected !\n')
  }

  # mutation_table$KaKs <-
  #   sum(mutation_table$Ka) / sum(mutation_table$Ks)
  # return(list(mutation_table, ka_ks = kaks))
  return(mutation_table)
}
