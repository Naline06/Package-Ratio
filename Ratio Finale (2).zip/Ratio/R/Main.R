# Ce fichier contient les valeurs par défaut pour les fonctions du package Ratio

utils::globalVariables(c("SN_table", "genetic_code", "genetic_code_path", "i", "n_core", "sn_table_path"))

