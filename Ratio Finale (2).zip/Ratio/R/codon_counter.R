# File: R/codon_counter.R

#' Compter l'occurrence des codons
#'
#' Cette fonction compte le nombre d'occurrences de chaque codon dans une séquence de référence et associe ces comptages aux informations synonyme et non-synonyme de la table SN
#'
#' @param ref Vecteur de codons de  la séquence de référence.
#' @param sn_table Table des codons synonymes et non synonymes.
#' @return Un data.frame contenant les codons, leur occurrence dans la séquence de référence et les valeurs S et N correspondantes.
#' @export

codon_counter <- function(ref, sn_table) {
  codon_count_table <- data.frame(codon = unique(ref), count = 0)
  for (i in 1:length(ref)) {
    codon.i <- ref[i]
    codon_count_table$count[match(codon.i, codon_count_table$codon)] <-
      codon_count_table$count[match(codon.i, codon_count_table$codon)] + 1
  }
  codon_count_table$S <- sn_table$S[match(codon_count_table$codon, sn_table$codon)]
  codon_count_table$N <- sn_table$N[match(codon_count_table$codon, sn_table$codon)]
  return(codon_count_table)
}
